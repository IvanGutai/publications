﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Helper
{
    public class ExtensionMethods
    {
    }
}

namespace System.Linq
{
    public static class MyLinqExtensions
    {
        // this is a chainable LINQ extension method
        public static IEnumerable<T> ProcessSequence<T>(this IEnumerable<T> sequence)
        {
            // you could do some processing here
            return sequence;
        }
        #region integers
        // these are scalar LINQ extension methods
        public static int? Median(this IEnumerable<int?> sequence)
        {
            int numberCount = sequence.Count();
            int halfIndex = sequence.Count() / 2;
            var sortedNumbers = sequence.OrderBy(n => n);
            int median;
            if ((numberCount % 2) == 0)
            {
                return median = Convert.ToInt32(((sortedNumbers.ElementAt(halfIndex) + sortedNumbers.ElementAt((halfIndex - 1))) / 2));
            }
            else
            {
                return median = Convert.ToInt32(sortedNumbers.ElementAt(halfIndex));
            }
        }

        public static int? Median<T>(this IEnumerable<T> sequence, Func<T, int?> selector)
        {
            return sequence.Select(selector).Median();
        }

        public static int? Mode(this IEnumerable<int?> sequence)
        {
            var mode = sequence.GroupBy(n => n).OrderByDescending(g => g.Count()).Select(g => g.Key).FirstOrDefault();
            return mode;
        }

        public static int? Mode<T>(this IEnumerable<T> sequence, Func<T, int?> selector)
        {
            return sequence.Select(selector).Mode();
        }
        #endregion
        public static decimal? Median(this IEnumerable<decimal?> sequence)
        {
            int numberCount = sequence.Count();
            int halfIndex = sequence.Count() / 2;
            var sortedNumbers = sequence.OrderBy(n => n);
            decimal median;
            if ((numberCount % 2) == 0)
            {
                return median = Convert.ToDecimal(((sortedNumbers.ElementAt(halfIndex)
                    + sortedNumbers.ElementAt((halfIndex - 1))) / 2));
            }
            else
            {
                return median = Convert.ToDecimal(sortedNumbers.ElementAt(halfIndex));
            }
        }

        public static decimal? Median<T>(this IEnumerable<T> sequence, Func<T, decimal?> selector)
        {
            return sequence.Select(selector).Median();
        }

        public static decimal? Mode(this IEnumerable<decimal?> sequence)
        {
            var mode = sequence.GroupBy(n => n)
                .OrderByDescending(g => g.Count()).Select(g => g.Key).FirstOrDefault();
            return mode;
        }

        public static decimal? Mode<T>(this IEnumerable<T> sequence, Func<T, decimal?> selector)
        {
            return sequence.Select(selector).Mode();
        }
    }
}
