﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Helper
{
    public static class Calculation
    {
        public static decimal GetRandomNumberInRange(decimal minNumber, decimal maxNumber)
        {
            return Convert.ToDecimal(new Random().NextDouble()) * (maxNumber - minNumber) + minNumber;
        }
    }
}
