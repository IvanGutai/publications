﻿using System;
using System.Linq;
using static Helper.Location;
using static Helper.Calculation;
using static System.Console;
using System.Diagnostics;
using Newtonsoft.Json.Linq;
using System.IO;
using Newtonsoft.Json;

namespace Helper
{
    public class SQLDataSource
    {

        public void LoadNItems(int NoOfItems)
        {
            using (var db = new DatabaseContext())
            {
                Console.WriteLine("{0,16} | {1,-27} | {2,13:N2} | {3,18:N2} | {4,10:N2} | {5,14:N2} |", "[BME280ResultID]", "[Timestamp]", "[Temperature]", "[RelativeHumidity]", "[Pressure]", "[LocationName]");

                var data = db.BME280Results.Join(
                inner: db.Locations,
                outerKeySelector: bm => bm.LocationID,
                innerKeySelector: lo => lo.LocationID,
                resultSelector: (b, l) =>
                new { b.BME280ResultID, b.Timestamp, b.Temperature, b.RelativeHumidity, b.Pressure, l.LocationName }).Take(NoOfItems);

                foreach (var item in data)
                {
                    Console.WriteLine("{0,16} | {1,27:dd.MM.yyyy. H:mm:ss zzz} | {2,-13:N2} | {3,-18:N2} | {4,-10:N2} | {5,14} |", item.BME280ResultID, item.Timestamp, item.Temperature, item.RelativeHumidity, item.Pressure, item.LocationName);
                }

            }
        }

        public void GenerateNItems(int NoOfItems)
        {
            using (var db = new DatabaseContext())
            {
                for (int i = 1; i < NoOfItems + 1; i++)
                {
                    var newEntry = new BME280Result();
                    //newEntry.BME280ResultID = i;
                    newEntry.Temperature = GetRandomNumberInRange(23, 32);
                    newEntry.RelativeHumidity = GetRandomNumberInRange(40, 60);
                    newEntry.Pressure = GetRandomNumberInRange(1010, 1030);
                    newEntry.LocationID = (int)GetRandomNumberInRange(1, 3);
                    db.BME280Results.Add(newEntry);

                    if (i % 10000 == 0)
                    {
                        var count = db.SaveChanges();
                        Console.WriteLine("{0} records saved to database", count);
                    }
                    else if (i == NoOfItems)
                    {
                        var count = db.SaveChanges();
                        Console.WriteLine("{0} records saved to database", count);

                    }
                    //count = db.SaveChanges();
                }
                //Console.WriteLine("{0} records saved to database", count);
            }
        }

        public void AverageMeanMedian()
        {
            using (var db = new DatabaseContext())
            {
                WriteLine("Mean Temperature: {0:N4}", db.BME280Results.Average(p => p.Temperature));
                WriteLine("Mean RelativeHumidity: {0:N4}", db.BME280Results.Average(p => p.RelativeHumidity));
                WriteLine("Mean Pressure: {0:N4}", db.BME280Results.Average(p => p.Pressure));
                WriteLine("Median Temperature: {0:N4}", db.BME280Results.Median(p => p.Temperature));
                WriteLine("Median RelativeHumidity: {0:N4}", db.BME280Results.Median(p => p.RelativeHumidity));
                WriteLine("Median Pressure: {0:N4}", db.BME280Results.Median(p => p.Pressure));
                WriteLine("Mode Temperature: {0:N4}", db.BME280Results.Mode(p => p.Temperature));
                WriteLine("Mode RelativeHumidity: {0:N4}", db.BME280Results.Mode(p => p.RelativeHumidity));
                WriteLine("Mode Pressure: {0:N4}", db.BME280Results.Mode(p => p.Pressure));
            }
        }

        public IQueryable GenerateJSON(int NoOfItems)
        {
            using (var db = new DatabaseContext())
            {
                var data = db.BME280Results.Join(
                inner: db.Locations,
                outerKeySelector: bm => bm.LocationID,
                innerKeySelector: lo => lo.LocationID,
                resultSelector: (b, l) =>
                new { b.BME280ResultID, b.Timestamp, b.Temperature, b.RelativeHumidity,
                    b.Pressure, l.LocationName }).Take(NoOfItems).OrderByDescending(b => b.BME280ResultID);

                var results = data.ToList();

                JObject json =
                    new JObject(
                        new JProperty("id", "MillenialDIY2020LE"),
                        new JProperty("BME280",
                            new JArray(
                                    from p in results
                                    orderby p.Timestamp
                                    select new JObject(
                                    new JProperty("BME280ResultID", p.BME280ResultID),
                                    new JProperty("Timestamp", p.Timestamp),
                                    new JProperty("Temperature", p.Temperature),
                                    new JProperty("RelativeHumidity", p.RelativeHumidity),
                                    new JProperty("Location", p.LocationName),
                                    new JProperty("Pressure", p.Pressure)))));

                File.WriteAllText(@"c:\results.json", JsonConvert.SerializeObject(json));

                // serialize JSON directly to a file
                using (StreamWriter file = File.CreateText(@"c:\results.json"))
                {
                    JsonSerializer serializer = new JsonSerializer();
                    serializer.Serialize(file, json);
                }

                return data;
            }
        }
    }
}
