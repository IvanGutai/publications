﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Helper
{
    class DataTypes
    {
    }

    public class Location
    {
        [Key]
        public int LocationID { get; set; }
        public string LocationName { get; set; }
        public virtual ICollection<BME280Result> BME280Results { get; set; }
        public Location()
        {
            this.BME280Results = new List<BME280Result>();
        }
        public class BME280Result
        {
            [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
            public int? BME280ResultID { get; set; }
            [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
            public DateTime Timestamp { get; set; }
            [Column(TypeName = "money")]
            public decimal Temperature { get; set; }
            [Column(TypeName = "money")]
            public decimal RelativeHumidity { get; set; }
            [Column(TypeName = "money")]
            public decimal Pressure { get; set; }
            public int LocationID { get; set; }
            public virtual Location Location { get; set; }
        }
    }

}
