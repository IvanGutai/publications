﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using static System.Console;
using System.Diagnostics;
using System.IO;
using Microsoft.EntityFrameworkCore.Storage;
using static Helper.Location;

namespace Helper
{

    public class DatabaseContext : DbContext
    {
        public DbSet<Location> Locations { get; set; }
        public DbSet<BME280Result> BME280Results { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            object p = optionsBuilder.UseSqlServer(@"Data Source=EDUG\GI_JOE;Initial Catalog=Expo2021;Integrated Security=true;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<BME280Result>().Property(b => b.Timestamp).HasDefaultValueSql("getdate()");

            modelBuilder.Entity<Location>().HasData
                (new Location { LocationID = 1, LocationName = "Office" }, new Location { LocationID = 2, LocationName = "Balcony" });

            /* modelBuilder.Entity<BME280Result>()
             .HasData(new BME280Result { BME280ResultID = -2, Temperature = 27, RelativeHumidity = 22, Pressure = 1004, LocationID = 1 },
             new BME280Result { BME280ResultID = -1, Temperature = 27.4M, RelativeHumidity = 28.1M, Pressure = 1012.7M, LocationID = 1 });*/
        }
    }

}
