﻿using System;
using static System.Console;
using Helper;

namespace GenerateAndProcess
{
    class Program
    {
        static void Main(string[] args)
        {
            var data = new SQLDataSource();
            //data.GenerateNItems(2);//(1_000_000);
            //data.LoadNItems(10);
            //data.GenerateJSON(2);
            data.AverageMeanMedian();
        }
    }
}
