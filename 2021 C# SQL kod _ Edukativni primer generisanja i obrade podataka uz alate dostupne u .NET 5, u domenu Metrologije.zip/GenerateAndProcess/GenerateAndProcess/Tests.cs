﻿using Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xunit;

namespace GenerateAndProcess
{
    public class Tests
    {
    }


    public class Calculator
    {
        public double Add(double a, double b)
        {
            return a + b;
        }
    }

    public static class Mode
    {
        public static decimal? Mode_Temperature()
        {
            using (var db = new DatabaseContext())
            {
                var result = db.BME280Results.Mode(p => p.Temperature);
                return result;
            }
        }

        public static decimal? Mode_RelativeHumidity()
        {
            using (var db = new DatabaseContext())
            {
                var result = db.BME280Results.Mode(p => p.RelativeHumidity);
                return result;
            }
        }

        public static decimal? Mode_Pressure()
        {
            using (var db = new DatabaseContext())
            {
                var result = db.BME280Results.Mode(p => p.Pressure);
                return result;
            }
        }
    }

    public class CustomUnitTests
    {

        [Fact]
        public void CalculateModeForTemperature()
        {
            // arrange
            decimal expected = 10M;
            // act 
            decimal? actual = Mode.Mode_Temperature();
            // assert
            Assert.Equal(expected, actual);
        }

        [Fact]
        public void CalculateModeForRelativeHumidity()
        {
            // arrange
            decimal expected = 55.9208M;
            // act 
            decimal? actual = Mode.Mode_RelativeHumidity();
            // assert
            Assert.Equal(expected, actual);
        }

        [Fact]
        public void CalculateModeForPressure()
        {
            // arrange
            decimal expected = 1018.8240M;
            // act 
            decimal? actual = Mode.Mode_Pressure();
            // assert
            Assert.Equal(expected, actual);
        }


    }


}
